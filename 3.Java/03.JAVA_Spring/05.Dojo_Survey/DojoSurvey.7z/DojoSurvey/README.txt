Dojo Survey

Topics:
● POST

Tasks:
● Create a 2 page app that will allow clients to fill out a form and see the form results.